// ==UserScript==
// @name         【真香】百度文库VIP/百度文库文档免费下载/baiduwenku/豆丁网VIP/豆丁网文档下载，极速秒破原文档+转换提取文档增强版，文档每页内容都可自由复制，整页可复制下来，移除百度文库广告，解除大部分网站右键操作等限制
// @namespace    wuxingsanren
// @version      1.0.6
// @description  免VIP下载百度文库免费和需下载券的原文档（转换下载不限类型、不限次数），文档单页内容自由随便复制，整个文档可以一键直接复制，移除百度文库全网网页广告；免VIP下载豆丁网文库文档（转换下载不限类型、不限次数）；解除大部分网站右键操作等限制，绝对是大家常用的好帮手，不仅省了买文库VIP的钱，还不闹心，美好的事情即将发生
// @author       wuxingsanren
// @icon 		 data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAVCAMAAAB1/u6nAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAFrUExURQAAAP/Mmdq8fNi4edi4eti4ev//qti5edm5edi4edu6fNm5eti5edm5edi5ev//gOO4gNi5eti5edi5edi4fNq6e9q5e9i7e9i4edi5etm5ety5gNm5edm4edm4etm4edm5edm4etu8fdy4eti5fNvbktm5etvCedi5etm5etm5eti4edu+fdi5etm5et6+fNq4fN27fdu9fN27iNi5etq5fNm6e928gNy5fdi4edm5edq7etm4etu5e9m4etm5euHDh9i5eti5e////9i5ef+/gNm5edu5e9i4et26fNm6etm5euPGjuS8hti5edy5eti4e9m6fNm4etm5etm4etvIgNm5ed+/gNm4etm5eevEidm5etm9e+K6gN69e9i5etq6eti5fNm4edu6edi6edu/gNm7e9q5etm5e9u7fNm8edi5etm6e9i6edu6fN+/gNi4etm4etm5edm5edq5e9q6etm4edy5e9i4eZQqRsQAAAB4dFJOUwAFRO759QP6ePJG9/T2qwISpZHsSGg+T7/77xYo/PH4UOs5QUIHxBWKurbfK76GJ2EtIw+ETHImM9nbS5tNlNYR2oMBuQS9W+Ala5kJE8wscEr9jtUOtyDqtQ3kGxof0zAhZT87HDxFX0A984GeTgi43OnwZojjOkPL3lUAAAEVSURBVBjTZZBVV8NAGAVvadKQupe64u7u7u7u7nZ/PhtSQqHzsOfsPN35AIHfpxiYQ8hjtbEAqV+3JTbaG0rztCUo9Wo266A9CIOMyqQfOJUpX6OAs1varPigI2d6SHXp7igVeryxMw2V7/gk5TrNdibIS9xREdqD6AtZWwm4h0nzOe6FfiLfkEmSFeWmelLJ4oosw/wzlRwmxeDqGvGc4ELiVBSIvdI8jRG9ZRXHaarN35Fxdg+NOjW77Vpf40q7vmqGnBifWyAPdywbZMdPwQA5i/3drU14yT4jzDJGLmHvAAExwvQb3DrI+LI4Wpg97sJDtPioLsYijDTiD0GJDpnhEvyjSRsYQBFVpLfYwuVxWozPFxsWSKrxM06/AAAAAElFTkSuQmCC
// @resource     vipLevel http://wkstatic.bdimg.com/static/wkusercenter/widget/new_uc/uc_myvip_s/image/icon-vip_6fb510a.png
// @require      http://cdn.staticfile.org/jquery/2.0.0/jquery.min.js
// @supportURL   http://yemao.in/wenku
// @include      *://wenku.baidu.com/*
// @include      *://api.ebuymed.cn/ext/*
// @include      *://apiebuymed.hurongnet.com/ext/1/*
// @include      *://www.ebuymed.cn/
// @include      *://*.docin.com/p*
// @include      *://www.bilibili.com/read/*
/*************** 解除网页限制 *************/
// @include      *://b.faloo.com/*
// @include      *://bbs.coocaa.com/*
// @include      *://book.hjsm.tom.com/*
// @include      *://book.zhulang.com/*
// @include      *://book.zongheng.com/*
// @include      *://book.hjsm.tom.com/*
// @include      *://chokstick.com/*
// @include      *://chuangshi.qq.com/*
// @include      *://yunqi.qq.com/*
// @include      *://city.udn.com/*
// @include      *://cutelisa55.pixnet.net/*
// @include      *://huayu.baidu.com/*
// @include      *://tiyu.baidu.com/*
// @include      *://yd.baidu.com/*
// @include      *://yuedu.baidu.com/*
// @include      *://imac.hk/*
// @include      *://life.tw/*
// @include      *://luxmuscles.com/*
// @include      *://read.qidian.com/*
// @include      *://www.15yan.com/*
// @include      *://www.17k.com/*
// @include      *://www.18183.com/*
// @include      *://www.360doc.com/*
// @include      *://www.eyu.com/*
// @include      *://www.hongshu.com/*
// @include      *://www.coco01.com/*
// @include      *://news.missevan.com/*
// @include      *://www.hongxiu.com/*
// @include      *://www.imooc.com/*
// @include      *://www.readnovel.com/*
// @include      *://www.tadu.com/*
// @include      *://www.jjwxc.net/*
// @include      *://www.xxsy.net/*
// @include      *://www.z3z4.com/*
// @include      *://yuedu.163.com/*
// @grant        GM_getResourceURL
// @grant        GM_xmlhttpRequest
// @grant        GM_getResourceText
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_download
// @grant        GM_addStyle
// @grant        GM_openInTab
// @run-at       document-idle
// @compatible	 Chrome
// @compatible	 Firefox
// @compatible	 Edge
// @compatible	 Safari
// @compatible	 Opera
// @compatible	 UC
// @license      GPL-3.0-only
// ==/UserScript==

(function() {
    'use strict';
    var $ = $ || window.$;
    var window_url = window.location.href;
    var website_host = window.location.host;
    //百度文库解析
    var baiduAnalysis={};
    baiduAnalysis.addHtml=function(){
        //只有百度文库才能通过
        if(window_url.indexOf("wenku.baidu.com/view")==-1 || website_host!="wenku.baidu.com"){
            return;
        }
        //iframe中不再执行
        if(window.top != window.self){
            return;
        }
        var vipLevelImg = GM_getResourceURL("vipLevel");
        //左边图标追加 - <br />
        var topBox = "<div style='position:fixed;z-index:999999;cursor:pointer;top:200px;left:0px;'>"+
            "<div id='crack_vip_document_box' style='text-align:center;font-size:13px;padding:10px 6px;color:#FFF;background-color:#19A97B;border-top-right-radius:6px;'><img src='" + vipLevelImg + "' style='width:20px;height:20px;position:relative;top:-2px;' />&nbsp;VIP下载</div>"+
            "<div id='crack_vip_copy_box' style='text-align:center;font-size:13px;padding:10px 6px;color:#FFF;background-color:#FE8A24;border-bottom-right-radius:6px;'>直接复制</div>"+
            "<div id='crack_vip_copy_box' style='font-size:13px;padding:6px 3px;background-color:#FCFCFC;'><a href='http://yemao.in' target='_blank' style='color:#3b8cff;'>http://yemao.in</a></div>"+
            "<div id='recommend_box' style='font-size:13px;padding:6px 3px;background-color:#FCFCFC;'><a href='javascript:;' target='_blank' style='color:#3b8cff;'>谷歌插件市场</a></div>"+
            "<div id='yemao_vip_box' style='width:105px;padding:6px 3px;'><iframe src='https://ghbtns.com/github-btn.html?user=wuxingsanren&repo=wildcat-vip-account&type=star&count=true' frameborder='0' style='height:20px;'></iframe></div>"+
            "</div>";
        $("body").append(topBox);
        //提取目标文档标题
        var searchWord = "";
        if($("#doc-tittle-0").length!=0){
            searchWord = $("#doc-tittle-0").text();
        }else if($("#doc-tittle-1").length!=0){
            searchWord = $("#doc-tittle-1").text();
        }else if($("#doc-tittle-2").length!=0){
            searchWord = $("#doc-tittle-2").text();
        }else if($("#doc-tittle-3").length!=0){
            searchWord = $("#doc-tittle-3").text();
        }
        //为每一页添加复制按钮
        var onePageCopyContentHtml = '<div class="copy-one-page-text" style="float:left;padding:3px 10px;position:relative;top:60px;font-size:14px;color:#fff;background-color:#FE8A24;border-top-right-radius:6px;border-bottom-right-radius:6px;z-index:999;cursor:pointer;">获取此页内容</div>';
        $('.mod.reader-page.complex, .ppt-page-item, .mod.reader-page-mod.complex').each(function() {
            $(this).prepend(onePageCopyContentHtml);
        });
        var defaultCrackVipUrl = "http://avip.fun/doc?url=#";
        $("body").on("click","#crack_vip_document_box",function(){
            defaultCrackVipUrl = defaultCrackVipUrl.replace(/@/g, encodeURIComponent(searchWord));
            defaultCrackVipUrl = defaultCrackVipUrl.replace(/#/g, encodeURIComponent(window_url));
            GM_setValue("document_url",window_url);
            window.open(defaultCrackVipUrl, "_blank");
        });
        $("body").on("click","#crack_vip_copy_box",function(){
            baiduAnalysis.copybaiduWenkuAll();
        });
        $("body").on("click",".copy-one-page-text",function(){
            var $inner = $(this).parent(".mod").find(".inner")
            baiduAnalysis.copybaiduWenkuOne($inner);
        });
    };
    baiduAnalysis.showBaiduCopyContentBox=function(str){
        var ua = navigator.userAgent;
        var opacity = '0.95';
        if (ua.indexOf("Edge") >= 0) {
            opacity = '0.6';
        } else{
            opacity = '0.95';
        }
        var copyTextBox = '<div id="copy-text-box" style="width:100%;height:100%;position: fixed;z-index: 9999;display: block;top: 0px;left: 0px;background:rgba(255,255,255,' + opacity + ');-webkit-backdrop-filter: blur(20px);display: flex;justify-content:center;align-items:center;">'+
            '<div id="copy-text-box-close" style="width:100%;height:100%;position:fixed;top:0px;left:0px;"></div>'+
            '<pre id="copy-text-content" style="width:60%;font-size:16px;line-height:22px;z-index:10000;white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;word-break:break-all;max-height:70%;overflow:auto;"></pre>'+
            '</div>"';
        $('#copy-text-box').remove();
        $('body').append(copyTextBox);
        $('#copy-text-content').html(str);
        $('#copy-text-box-close').click(function() {
            $('#copy-text-box').remove();
        });
    };
    baiduAnalysis.showDialog=function(str){
        var dialogHtml = '<div id="hint-dialog" style="margin:0px auto;opacity:0.8;padding:5px 10px;position:fixed;z-index: 10001;display: block;bottom:30px;left:44%;color:#fff;background-color:#CE480F;font-size:13px;border-radius:3px;">'+str+'</div>';
        $('#hint-dialog').remove();
        $('body').append(dialogHtml);
        timeoutId = setTimeout(function(){
            $('#hint-dialog').remove();
        }, 1500);
    }
    baiduAnalysis.copybaiduWenkuAll=function(){
        baiduAnalysis.copybaiduWenkuOne($(".inner"));
    };
    baiduAnalysis.copybaiduWenkuOne=function($inner){
        //提取文字
        var str = "";
        $inner.find('.reader-word-layer').each(function(){
            str += $(this).text().replace(/\u2002/g, ' ');
        });
        str = str.replace(/。\s/g, '。\r\n');
        //提取css中的图片
        var picHtml = "";
        var picUrlReg = /\(((\'|\")?https.*?)\)/i;
        var cssUrl = "";
        var picNum = 0;
        var picUrlLengthMin = 65;
        var picTemplate = "<div style='margin:10px 0px;text-align:center;'><img src='@' width='90%'><div>____图(#)____</div></div>";
        $inner.find('.reader-pic-item').each(function(){
            cssUrl= $(this).css("background-image");
            //在css中的情况
            if(!!cssUrl && (cssUrl.indexOf("https")!=-1 || cssUrl.indexOf("HTTPS")!=-1)){
                var array = cssUrl.match(picUrlReg);
                if(array.length>1){
                    cssUrl = array[1].replace(/\"/g, "");
                    if(!!cssUrl && cssUrl.length>picUrlLengthMin){
                        picNum ++;
                        var onePic = picTemplate;
                        onePic = onePic.replace(/#/g,picNum);
                        onePic = onePic.replace(/@/g,cssUrl);
                        picHtml += onePic;
                    }
                }
            }
        });
        //如果还有img标签，一并提取出来
        var srcUrl = "";
        $inner.find('img').each(function(){
            srcUrl = $(this).attr("src");
            if(!!srcUrl && srcUrl.length>picUrlLengthMin && srcUrl.indexOf("https://wkretype")!=-1){
                picNum ++;
                var onePic = picTemplate;
                onePic = onePic.replace(/#/g,picNum);
                onePic = onePic.replace(/@/g,srcUrl);
                picHtml += onePic;
            }
        });
        //追加内容
        var contentHtml = str+picHtml;
        if(!!contentHtml && contentHtml.length>0){
            if(picNum!=0){
                contentHtml = str+"<div style='color:red;text-align:center;margin-top:20px;'>文档中的图片如下：(图片可右键另存为)</div>"+picHtml;
            }
            baiduAnalysis.showBaiduCopyContentBox(contentHtml);
        }else{
            baiduAnalysis.showDialog("提取文档内容失败了");
        }
    };
    baiduAnalysis.download=function(){
        if("api.ebuymed.cn" == website_host || "apiebuymed.hurongnet.com" == website_host){
            var sendUrl = GM_getValue("document_url");
            if(!!sendUrl){
                GM_setValue("document_url","");
                $("#downurl").val(sendUrl);
                $("#buttondown").click();
            }
        }
    };
    baiduAnalysis.init=function(){
        baiduAnalysis.addHtml();
        baiduAnalysis.download();    //百度原文档下载
    }
    //百度文库部分初始化执行
    baiduAnalysis.init();
    //百度文库广告移除
    if(website_host.indexOf("wenku.baidu.com") != -1){
        var removeBaiduWenkuAd = {};
        removeBaiduWenkuAd.strt=function(){
            $(".banner-ad").hide();
            $(".union-ad-bottom").hide();
            //$("iframe").hide();

            //VIP去广告小按钮
            $(".ggbtm-vip-close").hide();
            $(".ad-vip-close-bottom").hide();
            $(".ad-vip-close").hide();

            //搜索页面
            $("#fengchaoad").hide();
            $(".search-aside-adWrap").hide();
        }
        removeBaiduWenkuAd.strt();
        setInterval(function(){
            removeBaiduWenkuAd.strt();
        },300);
    }
    //如果与百度文库相关，则执行至此
    if(website_host.indexOf("api.ebuymed.cn")!=-1 || website_host.indexOf("www.ebuymed.cn")!=-1 || website_host.indexOf("wenku.baidu.com")!=-1){
        return false;
    }
    ///豆丁文库开始
    var doudingAnalysis={};
    doudingAnalysis.judgeWebsite=function(){
        if(website_host.indexOf("docin.com")!=-1){
            return true;
        }
        return false;
    };
    doudingAnalysis.addStyle=function(){
        var innnerCss =
		`
        #plugin_doc_analysis_douding{position:fixed; top:160px; left:0px; background-color:red; z-index:999999;color:#FFF;}
		#plugin_doc_analysis_douding >.plugin_item{cursor:pointer; padding: 10px 2px; font-size:13px; text-align:center;}
		#plugin_doc_analysis_douding >.douding_download{background-color:#6DB324;}
		#plugin_doc_analysis_douding >.yemao_jump{background-color:#337AB7;}
		`;
        $("body").prepend("<style>"+innnerCss+"</style>");
    };
    doudingAnalysis.generateHtml=function(){
        var html="";
        html+= "<div id='plugin_doc_analysis_douding'>";
        html+= "<div class='plugin_item douding_download' title='豆丁文档免费下载，支持doc、pdf、txt'>下载</div>";
        html+= "<div class='plugin_item yemao_jump' title='1亿份文档免费下载'>文档</div>";
        html+= "</div>";
        $("body").append(html);
    };
    doudingAnalysis.operation=function(){
        var defaultCrackVipUrl = "http://avip.fun/doc?url=#";
        var searchWord = $(".doc_title").text();
        searchWord = !!searchWord ? searchWord : "文档";
        $("body").on("click", "#plugin_doc_analysis_douding .douding_download", function(){
            defaultCrackVipUrl = defaultCrackVipUrl.replace(/@/g, encodeURIComponent(searchWord));
            defaultCrackVipUrl = defaultCrackVipUrl.replace(/#/g, encodeURIComponent(window_url));
            window.open(defaultCrackVipUrl, "_blank");
        });
    };
    doudingAnalysis.start=function(){
        if(doudingAnalysis.judgeWebsite()){
            doudingAnalysis.addStyle();
            doudingAnalysis.generateHtml();
            doudingAnalysis.operation();
        }
    };
    doudingAnalysis.start();
    //与豆丁文档相关，执行至此
    if(website_host.indexOf("docin.com")!=-1){
        return false;
    }
    /*
     * 网页解除限制，集成了脚本：网页限制解除（精简优化版）
     * 作者：Cat73、xinggsf
     * 插件版本：1.5.6
     * 原插件地址：https://greasyfork.org/zh-CN/scripts/41075
     */
    //域名规则列表
    const rules = {
        plus: {
            name: "default",
            hook_eventNames: "contextmenu|select|selectstart|copy|cut|dragstart",
            unhook_eventNames: "mousedown|mouseup|keydown|keyup",
            dom0: true,
            hook_addEventListener: true,
            hook_preventDefault: true,
            add_css: true
        }
    };
    const returnTrue = e => true;
    // 获取目标域名应该使用的规则
    const getRule = (host) => {
        return rules.plus;
    };
    const dontHook = e => !!e.closest('form');
    //储存被 Hook 的函数
    const EventTarget_addEventListener = EventTarget.prototype.addEventListener;
    const document_addEventListener = document.addEventListener;
    const Event_preventDefault = Event.prototype.preventDefault;
    //要处理的 event 列表
    let hook_eventNames, unhook_eventNames, eventNames;

    //Hook addEventListener proc
    function addEventListener(type, func, useCapture) {
        let _addEventListener = this === document ? document_addEventListener : EventTarget_addEventListener;
        if (!hook_eventNames.includes(type)) {
            _addEventListener.apply(this, arguments);
        } else {
            _addEventListener.apply(this, [type, returnTrue, useCapture]);
        }
    }
    //清理或还原DOM节点的onxxx属性
    function clearLoop() {
        let type, prop,
            c = [document,document.body, ...document.getElementsByTagName('div')],
        //https://life.tw/?app=view&no=746862
        e = document.querySelector('iframe[src="about:blank"]');
        if (e && e.clientWidth>99 && e.clientHeight>11){
            e = e.contentWindow.document;
            c.push(e, e.body);
        }
        for (e of c) {
            if (!e) continue;
            e = e.wrappedJSObject || e;
            for (type of eventNames) {
                prop = 'on' + type;
                e[prop] = null;
            }
        }
    }
    function init() {
        //获取当前域名的规则
        let rule = getRule(location.host);
        //设置 event 列表
        hook_eventNames = rule.hook_eventNames.split("|");
        //Allowed to return value
        unhook_eventNames = rule.unhook_eventNames.split("|");
        eventNames = hook_eventNames.concat(unhook_eventNames);
        if (rule.dom0) {
            setInterval(clearLoop, 9e3);
            setTimeout(clearLoop, 1e3);
            window.addEventListener('load', clearLoop, true);
        }
        if (rule.hook_addEventListener) {
            EventTarget.prototype.addEventListener = addEventListener;
            document.addEventListener = addEventListener;
        }
        if (rule.hook_preventDefault) {
            Event.prototype.preventDefault = function () {
                if (dontHook(this.target) || !eventNames.includes(this.type)) {
                    Event_preventDefault.apply(this, arguments);
                }
            };
        }
        if (rule.add_css) GM_addStyle(
			`html, * {
            -webkit-user-select:text !important;
            -moz-user-select:text !important;
            user-select:text !important;
        }
    ::-moz-selection {color:#FFF!important; background:#3390FF!important;}
    ::selection {color:#FFF!important; background:#3390FF!important;}`
    );
    }
    init();
})();