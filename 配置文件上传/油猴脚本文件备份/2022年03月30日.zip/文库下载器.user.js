// ==UserScript==
// @name              文库下载器
// @version           0.3
// @namespace         https://waahah.gitee.io
// @description       百度文库解析下载功能 文档下载器 界面简洁，脚本仅限学习，请大家支持正版。
// @author            waahah
// @require           https://cdn.bootcss.com/jquery/3.5.1/jquery.min.js
// @match             *://wenku.baidu.com/view/*
// @match             *://wenku.baidu.com/tfview/*
// @match             *://wenku.baidu.com/link?url*
// @match             *://wenku.baidu.com/share/*
// @license           GPL License
// @grant             unsafeWindow
// @grant             GM_openInTab
// @grant             GM.openInTab
// @grant             GM_getValue
// @grant             GM.getValue
// @grant             GM_setValue
// @grant             GM.setValue
// @grant             GM_xmlhttpRequest
// @grant             GM.xmlHttpRequest
// @grant             GM_registerMenuCommand
// ==/UserScript==

(function() {
    'use strict';


$(function(){

    var webUrl = window.location.href;
    let webUrl2;
    let path = window.location.pathname.split("/")[1];
	var host = location.host;
    let tfpath = location.href.split("/");
	const InterfaceList = [ {"name":"wkdownload1","url":"http://www.html22.com/d/?url="},
                          {"name":"wkdownload2","url":""}
                        ]
    function GMxmlhttpRequest(obj) {
        if (typeof GM_xmlhttpRequest === "function") {
            GM_xmlhttpRequest(obj); }
        else {GM.xmlhttpRequest(obj);} }
    function GMopenInTab(url, open_in_background) {
        if (typeof GM_openInTab === "function") {
            GM_openInTab(url, open_in_background);
        }
            else {GM.openInTab(url, open_in_background); }}
    function after(obj){
        return obj.replace('/view/', '/share/').replace('.html', '') + '?share_api=1&width=800';
    }
    function css(css) {
		var myStyle = document.createElement('style');
        myStyle.textContent = css;
        var doc = document.head || document.documentElement;
		doc.appendChild(myStyle);
	}

	css(`#zuihuitao {cursor:pointer; position:fixed; top:100px; left:0px; width:0px; z-index:2147483647; font-size:12px; text-align:left;}
			#zuihuitao .logo { position: absolute;right: 0; width: 1.375rem;padding: 10px 2px;text-align: center;color: #fff;cursor: auto;user-select: none;border-radius: 0 4px 4px 0;transform: translate3d(100%, 5%, 0);background: deepskyblue;}
			#zuihuitao .die {display:none; position:absolute; left:28px; top:0; text-align:center;background-color:#04B4AE; border:1px solid gray;}
			#zuihuitao .die li{font-size:12px; color:#fff; text-align:center; width:60px; line-height:21px; float:left; border:1px solid gray;border-radius: 6px 6px 6px 6px; padding:0 4px; margin:4px 2px;list-style-type: none;}
			#zuihuitao .die li:hover{color:#fff;background:#FE2E64;}
			.add{background-color:#FE2E64;}`);

	var html = $(`<div id='zuihuitao'>
		    <div class='item_text'>
		        <div class="logo"><a id="m">文库下载</a></div>
		            <div class='die' >
		                <div style='display:flex;'>
		                    <div style='width:128px; padding:0px 0;'>
		                    <br>
		                        <div style='font-size:16px; text-align:center; color:#fff; line-height:21px;'>vvv解析</div>
		                        <ul style='margin:0 24px;'>
		                            <li id="li0">下载</li>
		                            <div style='clear:both;'></div>
		                        </ul>
		                        <br>
		                        <div style='font-size:16px; text-align:center; color:#fff; line-height:21px;'>bdwk解析</div>
		                        <ul style='margin:0 25px;'>
		                            <li id="li2">下载</li>
		                            <div style='clear:both;'></div>
		                        </ul>
		                        <br>
							</div>`);

    webUrl2 = after(webUrl);
	$("body").append(html);
	$(".item_text").on("mouseover", () => {
	        $(".die").show();
	    });
	    $(".item_text").on("mouseout", () => {
	        $(".die").hide();
	    });

	$("#li0").bind("click", () => {
	        window.open(InterfaceList[0].url + webUrl);
	});
    $("#li2").bind("click", () => {
            window.open( webUrl2,"_blank");
    });
    console.log(document.lastModified);

    if( path == "link"){
        let base_url = "https://wenku.baidu.com/user/interface/layerpop?act=get&platform=pc&layer_id=8";
			var xhttp = new XMLHttpRequest();
			xhttp.open("GET",base_url);
			xhttp.send(null);
			 xhttp.onreadystatechange = function() {
			  if (this.readyState == 4 && this.status == 200) {
					console.log('success');
                  var datas = xhttp.responseText;
					//console.log(xhttp.responseText);
                  datas=JSON.parse(datas);
                  console.log(datas);
                  const have = datas.data[8].data.pageInfo;
                  if(have !== undefined){
                      let url = have.referer;
                      console.log(url);
                      webUrl = url;
                      webUrl2 = after(url);
                      }else{
                          console.log('用户已登录账号 url为空,使用方案二');
                          const pageData = document.querySelector("body > script:nth-child(4)").innerText;
                          //console.log(pageData);
                          let DocId = pageData.indexOf('showDocId')+12;
                          let StoreId = pageData.indexOf('showStoreId')-3;
                          let showDocId = pageData.slice(DocId,StoreId);
                          const url = tfpath[0]+"//"+tfpath[2]+'/view/'+showDocId+".html";
                          console.log(url);
                          webUrl = url;
                          webUrl2 = after(url);
                  }

					}
				}
    }
    if( path == "tfview"){
        let tfurl = tfpath[0]+"//"+tfpath[2]+"/view/"+tfpath[4];
        let tfurl2 = after(tfurl);
        console.log(tfurl);
        webUrl = tfurl;
        webUrl2 = tfurl2;
    }
    function sleep(ms) {
     return new Promise(resolve => setTimeout(resolve, ms));
    }
    if( path == "share"){
        console.log(webUrl);
        $(".logo").hide();
        let ph = document.body.scrollHeight;
        let FPS = 1000;
        let retime = setInterval(function () {
            $(window).scrollTop( FPS,{ behavior: 'smooth'});
            FPS = FPS + 1000;
            if (FPS > ph) {
                clearInterval(retime);
                setTimeout(function () {
                    window.print();
                },500);

            }
        }, 300)

    }

});

})();